package store

const endHTMLContent = `</ul>
</body>
</html>`

const replaceHTMLContent = `</ul>`

const newTemplateContent = `
<html>
<head>
    <title>RSS Feed Summary</title>
</head>
<body>
    <h1>RSS Feed Summary</h1>
    <ul>
    </ul>
</body>
</html>
`
